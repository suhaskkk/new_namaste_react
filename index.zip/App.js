import React from "react";
import ReactDOM from "react-dom";

const Header = () => {
  return (
    <div className="header">
      <div className="logo-container">
        <img
          className="log"
          src="https://media.istockphoto.com/id/1038355632/vector/hamburger-icon.jpg?s=612x612&w=0&k=20&c=0lwYqfJxkss5KKmDPAFZRJ9_2-z3h1tRAfFyAKpVEYU="
          alt="food logo"
          //   style={{width:'70px'}}
        />
      </div>
      <div className="nav_items">
        <ul>
          <li>Home</li>
          <li>About</li>
          <li>Cart</li>
          <li>Cart</li>
        </ul>
      </div>
    </div>
  );
};

const FoodCard = (props) => {
const{resCard} = props
  const { resName, cuisine, stars, time ,img} = resCard;
  return (
    <div className="card_size">
      <img className="card_logo" src={img} alt="" />
      <h3>{resName}</h3>
      <h4>{cuisine}</h4>
      <h4>{stars}</h4>
      <h4>{time}</h4>
    </div>
  );
};

const Body = () => {
  return (
    <div>
      <div>
        <h3>search</h3>
      </div>
      <div className="food_card_container">
        {resData.map((restaurant) => (
          <FoodCard key={restaurant.id} resCard={restaurant} />
        ))}
      </div>
    </div>
  );
};

const resData = [
  {
    id: 1,
    img: "https://media-cdn.tripadvisor.com/media/photo-s/19/fa/13/d3/paneer-biryani.jpg",
    resName: "Meghna foods",
    cuisine: "Biryani,North indian,asian",
    stars: 4.4,
    time: "32 minutes",
  },
  {
    id: 2,
    img: "https://orderserv-kfc-assets.yum.com/15895bb59f7b4bb588ee933f8cd5344a/images/items/xs/D-K009.jpg?ver=35.42",
    resName: "Kfc",
    cuisine: "Chicken,North indian,asian",
    stars: 4.1,
    time: "35 minutes",
  },
  {
    id: 3,
    img: "https://media-cdn.tripadvisor.com/media/photo-s/16/8f/af/98/screenshot-20190221-213258.jpg",
    resName: "Mcdonald",
    cuisine: "Burger,North indian,asian",
    stars: 4.3,
    time: "40 minutes",
  },
  {
    id: 4,
    img: "https://i.insider.com/60a40faae25d05001880c4ff?width=1112&format=jpeg",
    resName: "Burger King",
    cuisine: "tikki,North indian,asian",
    stars: 4.2,
    time: "42 minutes",
  },
  {
    id: 5,
    img: "https://b.zmtcdn.com/data/pictures/7/19642507/2846c808d95faf8a5131a5d1a819b786.jpg",
    resName: "vrushali",
    cuisine: "chicken crispy,North indian,asian",
    stars: 4.2,
    time: "29 minutes",
  },
];

const AppLayout = () => {
  return (
    <div className="app">
      <Header />
      <Body />
    </div>
  );
};

const root = ReactDOM.createRoot(document.getElementById("root"));

root.render(<AppLayout />);
